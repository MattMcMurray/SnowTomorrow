from __future__ import absolute_import

from isort.main import main

main()
